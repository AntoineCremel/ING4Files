// ----------------------------------------------------
// NOTE: DO NOT REMOVE OR ALTER ANY LINE IN THIS SCRIPT
// ----------------------------------------------------

// Fill in the script as shown below:
print ("Query 00")				// the number of the question
// List all the documets		// the text of the question En
// Lister tous les documets		// the text of the question Fr
db.movieDetails.find()			// your answer on one 
								// or more lines
 				
// Ecrivez les requetes MongoDB qui retournent les informations ci-dessous,
// avec le schema de sortie demande :
// Write the MongoDB queries that return the information below,
// with the specified output schema:

print("Query 01")
// the salary and name of the employees whose commission is specified

      
print("Query 02")
// for each job, the job and the average salary in that job


print("Query 03")
// the name of the departments


print("Query 04")
// the job of the employees who did a mission (at least one)


print("Query 05")
// the number of employees

